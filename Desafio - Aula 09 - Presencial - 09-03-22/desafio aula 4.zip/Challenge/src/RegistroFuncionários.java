
public class RegistroFuncion�rios {

	public static void main(String[] args) {
		
		//Declarar vari�veis
		String cpf;
		int carteiraTrabalho;
		String nome;
		double salario;
		int cargaHoraria;
		
		
		//Atribuir valores
		cpf = "666.666.666-66";
		carteiraTrabalho = 555444555;
		nome = "Jo�o Trabalhador";
		salario = 15000;
		cargaHoraria = 8;
		
		//Printar na tela		
		System.out.println("Registro de funcion�rios");
		System.out.println("CPF: " + cpf);
		System.out.println("Carteira de Trabalho: " + carteiraTrabalho);
		System.out.println("Nome: " + nome);
		System.out.println("Sal�rio: R$" + salario);
		System.out.println("Carga Hor�ria: " + cargaHoraria + "horas");
		
		
		
		
		
	}

}
