
public class registroFornecedor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
// Declarar variaveis 
		
		String cnpj;
		String razaoSocial;
		String CEP;
		int numero;
		int telefone;
		String email;
		
		// Atribuir valores 
		
		cnpj = "00.112.112/0001-39";
		razaoSocial = " Condominio Residencial";
		CEP = "88790000";
		numero = 958036;
		telefone = 999999999;
		email = "joaozinho@gmail.com";
		
		//printar na tela
		
	System.out.println("DADOS FORNECEDOR");
	System.out.println("CNPJ" + cnpj);
	System.out.println("Raz�o Social" + razaoSocial);
	System.out.println("CEP" + CEP);
	System.out.println("N�mero:" + numero);
	System.out.println("Contato -" + telefone);
	System.out.println("Email :" + email);
		
	
		
		
		
				 
	
	}

}
