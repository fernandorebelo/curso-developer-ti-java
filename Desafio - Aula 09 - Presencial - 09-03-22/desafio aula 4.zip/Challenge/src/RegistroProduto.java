
public class RegistroProduto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Vari�veis declaradas 
		int codigo;
		String descricao;
		double precoCusto;
		double precoVenda;
		int quantidadeEstoque;
		
		// Atribui��o de valor 
		
		codigo = 51436;
		descricao = "Bola de futebol";
		precoCusto = 50;
		precoVenda = 90;
		quantidadeEstoque = 500;
		
		// Printar 
		
		System.out.println("Codigo - " + codigo); 
		System.out.println("Descri��o: " + descricao); 
		System.out.println("Pre�o Custo R$" + precoCusto); 
		System.out.println("Pre�o Venda R$" + precoVenda); 
		System.out.println("Quantidade em estoque: " + quantidadeEstoque+" UNIDADES");
		
	
			
			
	}

}
